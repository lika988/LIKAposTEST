
# LIKApos - Multi-Version Structure

This repository contains:
- Desktop, Tablet, and Mobile HTML files separated.
- Automatic device detection from index.html.
- Ready for Cloudflare Pages and GitHub Pages deployment.

Structure:
- /index.html (redirect logic)
- /views/desktop.html
- /views/tablet.html
- /views/mobile.html
- /css/*.css
- /js/*.js
